#!/bin/sh

cd /projects/aggregator-flink
exec /opt/maven/bin/mvn compile exec:exec

