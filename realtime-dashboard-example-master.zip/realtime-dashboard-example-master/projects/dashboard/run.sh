#!/bin/sh

cd /projects/dashboard
exec npm start
